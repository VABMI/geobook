# SEOR Login

Login For a System of Store Management for SEOR Algerian company

```
SEORLogin
  |-------css
  |        |-----font
  |        |      |------Aller_BdIt.ttf
  |        |
  |        |-----main.css
  |        |-----animate.css
  |
  |-------logo
  |        |-----User.png
  |        |-----Lock.png
  |        |-----seor.png
  |
  |-------index.html
```
